Colocando o height para 20vw no celular e no tablet para 12vw. e upando para development
